import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { MainLayout } from "@/components/layout/MainLayout";
import { Toaster } from "@/components/ui/toaster";
import { Home, Video, Users, Building, Bell } from "lucide-react";

const inter = Inter({ subsets: ["latin"] });

const navigationItems = [
  {
    name: "Dashboard",
    path: "/",
    icon: <Home className="h-5 w-5" />,
  },
  {
    name: "Live Feed",
    path: "/live-feed",
    icon: <Video className="h-5 w-5" />,
  },
  {
    name: "Workers",
    path: "/workers",
    icon: <Users className="h-5 w-5" />,
  },
  {
    name: "Sites",
    path: "/sites",
    icon: <Building className="h-5 w-5" />,
  },
  {
    name: "Notifications",
    path: "/notifications",
    icon: <Bell className="h-5 w-5" />,
  },
];

export const metadata: Metadata = {
  title: "Construction Site Monitor",
  description: "Real-time construction site monitoring dashboard",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <MainLayout>{children}</MainLayout>
        <Toaster />
      </body>
    </html>
  );
}
