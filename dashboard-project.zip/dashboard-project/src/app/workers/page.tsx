"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/store/useStore";
import type { Worker } from "@/store/useStore";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function WorkersPage() {
  const { workers, addWorker, updateWorker, removeWorker } = useStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [dbWorkers, setDbWorkers] = useState<any[]>([]);
  const [formData, setFormData] = useState<Partial<Worker>>({
    firstName: "",
    lastName: "",
    employeeId: "",
    department: "",
    position: "",
    dateOfBirth: "",
    dateOfJoining: "",
    contactNumber: "",
    email: "",
    address: "",
    emergencyContact: {
      name: "",
      relationship: "",
      phone: "",
    },
    qualifications: [],
    certifications: [],
    workSchedule: {
      shift: "morning",
      workingHours: "",
      daysOff: [],
    },
    salary: {
      basic: 0,
      allowances: 0,
      deductions: 0,
      netSalary: 0,
    },
    attendance: {
      totalDays: 0,
      present: 0,
      absent: 0,
      late: 0,
    },
    performance: {
      lastReviewDate: "",
      rating: 0,
      feedback: "",
    },
    documents: [],
  });

  // Fetch workers from the database
  useEffect(() => {
    const fetchWorkers = async () => {
      try {
        setIsLoading(true);
        const response = await fetch("/api/workers");
        if (!response.ok) {
          throw new Error("Failed to fetch workers");
        }
        const data = await response.json();
        setDbWorkers(data);
      } catch (error) {
        console.error("Error fetching workers:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchWorkers();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingWorker) {
        // Update existing worker
        const response = await fetch(`/api/workers/${editingWorker.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        if (!response.ok) {
          throw new Error("Failed to update worker");
        }

        const updatedWorker = await response.json();
        updateWorker({ ...editingWorker, ...updatedWorker } as Worker);

        // Refresh the workers list
        const workersResponse = await fetch("/api/workers");
        const workersData = await workersResponse.json();
        setDbWorkers(workersData);
      } else {
        // Create new worker
        const response = await fetch("/api/workers", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        if (!response.ok) {
          throw new Error("Failed to create worker");
        }

        const newWorker = await response.json();
        addWorker({ ...formData, id: newWorker.id } as Worker);

        // Refresh the workers list
        const workersResponse = await fetch("/api/workers");
        const workersData = await workersResponse.json();
        setDbWorkers(workersData);
      }

      setIsDialogOpen(false);
      setEditingWorker(null);
      resetForm();
    } catch (error) {
      console.error("Error saving worker:", error);
    }
  };

  const handleEdit = async (worker: Worker) => {
    try {
      const response = await fetch(`/api/workers/${worker.id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch worker details");
      }
      const workerData = await response.json();

      setEditingWorker(worker);
      setFormData(workerData);
      setIsDialogOpen(true);
    } catch (error) {
      console.error("Error fetching worker details:", error);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/workers/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Delete error response:", errorData);
        throw new Error(errorData.error || "Failed to delete worker");
      }

      removeWorker(id);

      // Refresh the workers list
      const workersResponse = await fetch("/api/workers");
      if (workersResponse.ok) {
        const workersData = await workersResponse.json();
        setDbWorkers(workersData);
      }
    } catch (error) {
      console.error("Error deleting worker:", error);
      // You could add a toast notification here to inform the user
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      employeeId: "",
      department: "",
      position: "",
      dateOfBirth: "",
      dateOfJoining: "",
      contactNumber: "",
      email: "",
      address: "",
      emergencyContact: {
        name: "",
        relationship: "",
        phone: "",
      },
      qualifications: [],
      certifications: [],
      workSchedule: {
        shift: "morning",
        workingHours: "",
        daysOff: [],
      },
      salary: {
        basic: 0,
        allowances: 0,
        deductions: 0,
        netSalary: 0,
      },
      attendance: {
        totalDays: 0,
        present: 0,
        absent: 0,
        late: 0,
      },
      performance: {
        lastReviewDate: "",
        rating: 0,
        feedback: "",
      },
      documents: [],
    });
  };

  // Use dbWorkers for display if available, otherwise fall back to store workers
  const displayWorkers = dbWorkers.length > 0 ? dbWorkers : workers;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold">Workers</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="text-base px-6 py-5">Add Worker</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">
                {editingWorker ? "Edit Worker" : "Add New Worker"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs defaultValue="personal" className="w-full">
                <TabsList className="grid w-full grid-cols-4 gap-1">
                  <TabsTrigger value="personal" className="px-2 sm:px-4">
                    Personal
                  </TabsTrigger>
                  <TabsTrigger value="employment" className="px-2 sm:px-4">
                    Employment
                  </TabsTrigger>
                  <TabsTrigger value="schedule" className="px-2 sm:px-4">
                    Schedule
                  </TabsTrigger>
                  <TabsTrigger value="performance" className="px-2 sm:px-4">
                    Performance
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="personal" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            firstName: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) =>
                          setFormData({ ...formData, lastName: e.target.value })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contactNumber">Contact Number</Label>
                    <Input
                      id="contactNumber"
                      value={formData.contactNumber}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          contactNumber: e.target.value,
                        })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      required
                    />
                  </div>
                </TabsContent>
                <TabsContent value="employment" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="employeeId">Employee ID</Label>
                      <Input
                        id="employeeId"
                        value={formData.employeeId}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            employeeId: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">Department</Label>
                      <Input
                        id="department"
                        value={formData.department}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            department: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="position">Position</Label>
                      <Input
                        id="position"
                        value={formData.position}
                        onChange={(e) =>
                          setFormData({ ...formData, position: e.target.value })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dateOfJoining">Date of Joining</Label>
                      <Input
                        id="dateOfJoining"
                        type="date"
                        value={formData.dateOfJoining}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            dateOfJoining: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="schedule" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="shift">Shift</Label>
                    <Select
                      value={formData.workSchedule?.shift}
                      onValueChange={(
                        value: "morning" | "afternoon" | "night"
                      ) =>
                        setFormData({
                          ...formData,
                          workSchedule: {
                            shift: value,
                            workingHours:
                              formData.workSchedule?.workingHours || "",
                            daysOff: formData.workSchedule?.daysOff || [],
                          },
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select shift" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning</SelectItem>
                        <SelectItem value="afternoon">Afternoon</SelectItem>
                        <SelectItem value="night">Night</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="workingHours">Working Hours</Label>
                    <Input
                      id="workingHours"
                      value={formData.workSchedule?.workingHours}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          workSchedule: {
                            shift: formData.workSchedule?.shift || "morning",
                            workingHours: e.target.value,
                            daysOff: formData.workSchedule?.daysOff || [],
                          },
                        })
                      }
                      required
                    />
                  </div>
                </TabsContent>
                <TabsContent value="performance" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="rating">Performance Rating</Label>
                    <Input
                      id="rating"
                      type="number"
                      min="1"
                      max="5"
                      value={formData.performance?.rating}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          performance: {
                            lastReviewDate:
                              formData.performance?.lastReviewDate || "",
                            rating: parseInt(e.target.value),
                            feedback: formData.performance?.feedback || "",
                          },
                        })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="feedback">Feedback</Label>
                    <Input
                      id="feedback"
                      value={formData.performance?.feedback}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          performance: {
                            lastReviewDate:
                              formData.performance?.lastReviewDate || "",
                            rating: formData.performance?.rating || 0,
                            feedback: e.target.value,
                          },
                        })
                      }
                      required
                    />
                  </div>
                </TabsContent>
              </Tabs>
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    setEditingWorker(null);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit">
                  {editingWorker ? "Update Worker" : "Add Worker"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-40">
          <p className="text-lg">Loading workers...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {displayWorkers.map((worker: Worker) => (
            <Card key={worker.id} className="overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-xl font-bold">
                  {worker.firstName} {worker.lastName}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(worker)}
                    className="text-sm"
                  >
                    Edit
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(worker.id)}
                    className="text-sm"
                  >
                    Delete
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground space-y-2 leading-none">
                  <p>Position: {worker.position}</p>
                  <p>Department: {worker.department}</p>
                  <p>Employee ID: {worker.employeeId}</p>
                  <p>Email: {worker.email}</p>
                  <p>Contact: {worker.contactNumber}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
