"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/store/useStore";
import Link from "next/link";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { GoogleGenerativeAI } from "@google/generative-ai";
import type { SafetyViolation, SiteInfo, Worker } from "@/store/useStore";
import { Users, Building2, AlertTriangle } from "lucide-react";

const WORKER_MIN = 5;
const WORKER_MAX = 25;
const SAFETY_MIN = 70;
const SAFETY_MAX = 100;
const VIOLATION_PROBABILITY = 0.7;
const ANALYSIS_INTERVAL = 5000;

const SAFETY_COLORS = ["#10b981", "#f59e0b", "#ef4444"];

const genAI = new GoogleGenerativeAI(
  process.env.NEXT_PUBLIC_GEMINI_API_KEY || "",
);

export default function DashboardPage() {
  const { workers, sites, safetyViolations } = useStore();
  const [safetyStats, setSafetyStats] = useState<{
    low: number;
    medium: number;
    high: number;
  }>({
    low: 0,
    medium: 0,
    high: 0,
  });
  
  // Calculate safety stats from violations
  useEffect(() => {
    // Count violations by severity
    const counts = {
      low: 0,
      medium: 0,
      high: 0,
    };
    
    safetyViolations.forEach(violation => {
      counts[violation.severity]++;
    });
    
    setSafetyStats(counts);
  }, [safetyViolations]);
  
  // Convert safety stats to format needed for pie chart
  const pieData = [
    { name: "Low", value: safetyStats.low },
    { name: "Medium", value: safetyStats.medium },
    { name: "High", value: safetyStats.high },
  ].filter(item => item.value > 0);
  
  // Calculate active sites
  const activeSites = sites.filter(site => site.siteStatus === "active").length;

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold leading-none">Dashboard</h1>
      
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium leading-none">Total Workers</CardTitle>
            <Users className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold leading-none">{workers.length}</div>
            <p className="text-xs text-muted-foreground mt-1 leading-none">
              Across all construction sites
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium leading-none">Active Sites</CardTitle>
            <Building2 className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold leading-none">{activeSites}</div>
            <p className="text-xs text-muted-foreground mt-1 leading-none">
              Out of {sites.length} total sites
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium leading-none">Safety Violations</CardTitle>
            <AlertTriangle className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold leading-none">{safetyViolations.length}</div>
            <Link href="/notifications" className="text-xs text-blue-500 hover:underline mt-1 flex items-center leading-none">
              View all notifications
            </Link>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts */}
      <div>
        <Card>
          <CardHeader>
            <CardTitle className="leading-none">Violation Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => 
                        `${name}: ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {pieData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={SAFETY_COLORS[index % SAFETY_COLORS.length]} 
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center">
                  <p className="text-muted-foreground leading-none">No violation data available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Violations */}
      <Card>
        <CardHeader>
          <CardTitle className="leading-none">Recent Safety Violations</CardTitle>
        </CardHeader>
        <CardContent>
          {safetyViolations.length === 0 ? (
            <p className="text-center text-muted-foreground py-4 leading-none">No safety violations recorded</p>
          ) : (
            <div className="space-y-4">
              {safetyViolations
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .slice(0, 5)
                .map((violation) => (
                  <div key={violation.id} className="flex justify-between items-start border-b pb-4">
                    <div>
                      <h3 className="font-medium leading-none">{violation.type}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-1 mt-2 leading-none">
                        {violation.description}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2 leading-none">
                        {new Date(violation.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <div className={`px-2 py-1 rounded-md text-xs font-medium leading-none ${
                      violation.severity === 'high' 
                        ? 'bg-red-100 text-red-800' 
                        : violation.severity === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                    }`}>
                      {violation.severity.toUpperCase()}
                    </div>
                  </div>
                ))}
              <div className="text-center pt-2">
                <Link href="/notifications" className="text-sm text-blue-500 hover:underline leading-none">
                  View all notifications
                </Link>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
