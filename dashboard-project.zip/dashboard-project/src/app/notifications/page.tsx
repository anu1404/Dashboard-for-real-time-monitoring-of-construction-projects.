"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/store/useStore";
import type { SafetyViolation } from "@/store/useStore";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

export default function NotificationsPage() {
  const { safetyViolations } = useStore();
  const [filter, setFilter] = useState<"all" | "low" | "medium" | "high">("all");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");

  const filteredViolations = safetyViolations.filter(violation => 
    filter === "all" || violation.severity === filter
  );

  const sortedViolations = [...filteredViolations].sort((a, b) => {
    const dateA = new Date(a.timestamp).getTime();
    const dateB = new Date(b.timestamp).getTime();
    return sortOrder === "newest" ? dateB - dateA : dateA - dateB;
  });

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold leading-none">Safety Notifications</h1>
        <div className="flex gap-4">
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium leading-none">Filter by Severity</span>
            <Select value={filter} onValueChange={(value: "all" | "low" | "medium" | "high") => setFilter(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Notifications</SelectItem>
                <SelectItem value="low">Low Severity</SelectItem>
                <SelectItem value="medium">Medium Severity</SelectItem>
                <SelectItem value="high">High Severity</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium leading-none">Sort by</span>
            <Select value={sortOrder} onValueChange={(value: "newest" | "oldest") => setSortOrder(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort order" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {sortedViolations.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground leading-none">No safety notifications found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sortedViolations.map((violation) => (
            <Card key={violation.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-xl font-bold leading-none">{violation.type}</CardTitle>
                  <Badge 
                    variant={
                      violation.severity === "high" 
                        ? "destructive" 
                        : violation.severity === "medium" 
                          ? "default" 
                          : "secondary"
                    }
                    className="leading-none"
                  >
                    {violation.severity.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground leading-none mt-2">
                  {format(new Date(violation.timestamp), "PPP p")}
                </p>
              </CardHeader>
              <CardContent>
                <p className="leading-none">{violation.description}</p>
                {violation.workerId && (
                  <p className="mt-2 text-sm text-muted-foreground leading-none">Worker ID: {violation.workerId}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
} 