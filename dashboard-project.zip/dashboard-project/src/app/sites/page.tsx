"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/store/useStore";
import type { SiteInfo } from "@/store/useStore";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SitesPage() {
  const {
    sites,
    addSite,
    updateSite,
    removeSite,
    selectedSite,
    setSelectedSite,
  } = useStore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSite, setEditingSite] = useState<SiteInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [dbSites, setDbSites] = useState<any[]>([]);
  const [formData, setFormData] = useState<Partial<SiteInfo>>({
    name: "",
    location: "",
    projectType: "",
    startDate: "",
    expectedCompletionDate: "",
    totalWorkers: 0,
    safetyCompliance: 0,
    lastUpdated: new Date().toISOString(),
    siteManager: {
      name: "",
      contactNumber: "",
    },
    emergencyContacts: [],
    safetyOfficer: {
      name: "",
      contactNumber: "",
      certificationNumber: "",
    },
    siteStatus: "active",
    workHours: {
      start: "",
      end: "",
      breakTimes: [],
    },
    safetyMeasures: {
      firstAidKits: 0,
      fireExtinguishers: 0,
      emergencyExits: 0,
      safetySigns: false,
      lastSafetyAudit: "",
    },
    equipment: [],
    permits: [],
  });

  // Fetch sites from the database
  useEffect(() => {
    const fetchSites = async () => {
      try {
        setIsLoading(true);
        const response = await fetch("/api/sites");
        if (!response.ok) {
          throw new Error("Failed to fetch sites");
        }
        const data = await response.json();
        setDbSites(data);
      } catch (error) {
        console.error("Error fetching sites:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSites();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingSite) {
        // Update existing site
        const response = await fetch(`/api/sites/${editingSite.id}`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        if (!response.ok) {
          throw new Error("Failed to update site");
        }

        const updatedSite = await response.json();
        updateSite({ ...editingSite, ...updatedSite } as SiteInfo);

        // Refresh the sites list
        const sitesResponse = await fetch("/api/sites");
        const sitesData = await sitesResponse.json();
        setDbSites(sitesData);
      } else {
        // Create new site
        const response = await fetch("/api/sites", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        if (!response.ok) {
          throw new Error("Failed to create site");
        }

        const newSite = await response.json();
        addSite({ ...formData, id: newSite.id } as SiteInfo);

        // Refresh the sites list
        const sitesResponse = await fetch("/api/sites");
        const sitesData = await sitesResponse.json();
        setDbSites(sitesData);
      }

      setIsDialogOpen(false);
      setEditingSite(null);
      resetForm();
    } catch (error) {
      console.error("Error saving site:", error);
    }
  };

  const handleEdit = async (site: SiteInfo) => {
    try {
      const response = await fetch(`/api/sites/${site.id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch site details");
      }
      const siteData = await response.json();

      setEditingSite(site);
      setFormData(siteData);
      setIsDialogOpen(true);
    } catch (error) {
      console.error("Error fetching site details:", error);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/sites/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Delete error response:", errorData);
        throw new Error(errorData.error || "Failed to delete site");
      }

      removeSite(id);

      // Refresh the sites list
      const sitesResponse = await fetch("/api/sites");
      if (sitesResponse.ok) {
        const sitesData = await sitesResponse.json();
        setDbSites(sitesData);
      }
    } catch (error) {
      console.error("Error deleting site:", error);
      // You could add a toast notification here to inform the user
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      location: "",
      projectType: "",
      startDate: "",
      expectedCompletionDate: "",
      totalWorkers: 0,
      safetyCompliance: 100,
      lastUpdated: new Date().toISOString(),
      siteManager: {
        name: "",
        contactNumber: "",
      },
      emergencyContacts: [],
      safetyOfficer: {
        name: "",
        contactNumber: "",
        certificationNumber: "",
      },
      siteStatus: "active",
      workHours: {
        start: "",
        end: "",
        breakTimes: [],
      },
      safetyMeasures: {
        firstAidKits: 0,
        fireExtinguishers: 0,
        emergencyExits: 0,
        safetySigns: false,
        lastSafetyAudit: "",
      },
      equipment: [],
      permits: [],
    });
  };

  // Use dbSites for display if available, otherwise fall back to store sites
  const displaySites = dbSites.length > 0 ? dbSites : sites;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold">Construction Sites</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="text-base px-6 py-5">Add Site</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">
                {editingSite ? "Edit Site" : "Add New Site"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-2 gap-1">
                  <TabsTrigger value="basic" className="px-2 sm:px-4">
                    Basic Info
                  </TabsTrigger>
                  <TabsTrigger value="contacts" className="px-2 sm:px-4">
                    Contacts
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Site Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={formData.location}
                        onChange={(e) =>
                          setFormData({ ...formData, location: e.target.value })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="projectType">Project Type</Label>
                      <Input
                        id="projectType"
                        value={formData.projectType}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            projectType: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="siteStatus">Site Status</Label>
                      <Select
                        value={formData.siteStatus}
                        onValueChange={(
                          value: "active" | "completed" | "on-hold"
                        ) => setFormData({ ...formData, siteStatus: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="on-hold">On Hold</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Start Date</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={formData.startDate}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            startDate: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="expectedCompletionDate">
                        Expected Completion
                      </Label>
                      <Input
                        id="expectedCompletionDate"
                        type="date"
                        value={formData.expectedCompletionDate}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            expectedCompletionDate: e.target.value,
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="workHoursStart">Work Hours Start</Label>
                      <Input
                        id="workHoursStart"
                        type="time"
                        value={formData.workHours?.start || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            workHours: {
                              start: e.target.value,
                              end: formData.workHours?.end || "",
                              breakTimes: formData.workHours?.breakTimes || [],
                            },
                          })
                        }
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="workHoursEnd">Work Hours End</Label>
                      <Input
                        id="workHoursEnd"
                        type="time"
                        value={formData.workHours?.end || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            workHours: {
                              start: formData.workHours?.start || "",
                              end: e.target.value,
                              breakTimes: formData.workHours?.breakTimes || [],
                            },
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="contacts" className="space-y-4">
                  <div className="space-y-2">
                    <Label>Site Manager</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        placeholder="Name"
                        value={formData.siteManager?.name || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            siteManager: {
                              name: e.target.value,
                              contactNumber:
                                formData.siteManager?.contactNumber || "",
                            },
                          })
                        }
                        required
                      />
                      <Input
                        placeholder="Contact Number"
                        value={formData.siteManager?.contactNumber || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            siteManager: {
                              name: formData.siteManager?.name || "",
                              contactNumber: e.target.value,
                            },
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Safety Officer</Label>
                    <div className="grid grid-cols-3 gap-4">
                      <Input
                        placeholder="Name"
                        value={formData.safetyOfficer?.name || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            safetyOfficer: {
                              name: e.target.value,
                              contactNumber:
                                formData.safetyOfficer?.contactNumber || "",
                              certificationNumber:
                                formData.safetyOfficer?.certificationNumber ||
                                "",
                            },
                          })
                        }
                        required
                      />
                      <Input
                        placeholder="Contact Number"
                        value={formData.safetyOfficer?.contactNumber || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            safetyOfficer: {
                              name: formData.safetyOfficer?.name || "",
                              contactNumber: e.target.value,
                              certificationNumber:
                                formData.safetyOfficer?.certificationNumber ||
                                "",
                            },
                          })
                        }
                        required
                      />
                      <Input
                        placeholder="Certification Number"
                        value={
                          formData.safetyOfficer?.certificationNumber || ""
                        }
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            safetyOfficer: {
                              name: formData.safetyOfficer?.name || "",
                              contactNumber:
                                formData.safetyOfficer?.contactNumber || "",
                              certificationNumber: e.target.value,
                            },
                          })
                        }
                        required
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    setEditingSite(null);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit">
                  {editingSite ? "Update Site" : "Add Site"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-40">
          <p className="text-lg">Loading sites...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {displaySites.map((site: SiteInfo) => (
            <Card key={site.id} className="overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="text-xl font-medium">
                  {site.name}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(site)}
                    className="text-sm"
                  >
                    Edit
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(site.id)}
                    className="text-sm"
                  >
                    Delete
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground space-y-2 leading-none">
                  <p>Location: {site.location}</p>
                  <p>Project Type: {site.projectType}</p>
                  <p>Status: {site.siteStatus}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
