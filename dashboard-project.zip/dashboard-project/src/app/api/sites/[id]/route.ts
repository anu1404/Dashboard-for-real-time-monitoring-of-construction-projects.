import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

interface Params {
  params: {
    id: string;
  };
}

// GET a specific site
export async function GET(request: Request, { params }: Params) {
  try {
    const { id } = params;
    const site = await prisma.site.findUnique({
      where: {
        id,
      },
    });

    if (!site) {
      return NextResponse.json(
        { error: 'Site not found' },
        { status: 404 }
      );
    }

    // Parse the JSON fields
    const parsedSite = {
      ...site,
      siteManager: site.siteManager ? JSON.parse(site.siteManager as string) : {},
      emergencyContacts: site.emergencyContacts ? JSON.parse(site.emergencyContacts as string) : [],
      safetyOfficer: site.safetyOfficer ? JSON.parse(site.safetyOfficer as string) : {},
      workHours: site.workHours ? JSON.parse(site.workHours as string) : {},
      safetyMeasures: site.safetyMeasures ? JSON.parse(site.safetyMeasures as string) : {},
      equipment: site.equipment ? JSON.parse(site.equipment as string) : [],
      permits: site.permits ? JSON.parse(site.permits as string) : [],
    };

    return NextResponse.json(parsedSite);
  } catch (error) {
    console.error('Error fetching site:', error);
    return NextResponse.json(
      { error: 'Failed to fetch site' },
      { status: 500 }
    );
  }
}

// PATCH update a site
export async function PATCH(request: Request, { params }: Params) {
  try {
    const { id } = params;
    const body = await request.json();

    // Prepare the data with stringified JSON fields
    const updateData: any = {};
    
    // Handle primitive fields
    if (body.name !== undefined) updateData.name = body.name;
    if (body.location !== undefined) updateData.location = body.location;
    if (body.projectType !== undefined) updateData.projectType = body.projectType;
    if (body.startDate !== undefined) updateData.startDate = body.startDate;
    if (body.expectedCompletionDate !== undefined) updateData.expectedCompletionDate = body.expectedCompletionDate;
    if (body.totalWorkers !== undefined) updateData.totalWorkers = body.totalWorkers;
    if (body.safetyCompliance !== undefined) updateData.safetyCompliance = body.safetyCompliance;
    if (body.lastUpdated !== undefined) updateData.lastUpdated = body.lastUpdated;
    if (body.siteStatus !== undefined) updateData.siteStatus = body.siteStatus;
    
    // Handle JSON fields
    if (body.siteManager !== undefined) updateData.siteManager = JSON.stringify(body.siteManager);
    if (body.emergencyContacts !== undefined) updateData.emergencyContacts = JSON.stringify(body.emergencyContacts);
    if (body.safetyOfficer !== undefined) updateData.safetyOfficer = JSON.stringify(body.safetyOfficer);
    if (body.workHours !== undefined) updateData.workHours = JSON.stringify(body.workHours);
    if (body.safetyMeasures !== undefined) updateData.safetyMeasures = JSON.stringify(body.safetyMeasures);
    if (body.equipment !== undefined) updateData.equipment = JSON.stringify(body.equipment);
    if (body.permits !== undefined) updateData.permits = JSON.stringify(body.permits);

    const site = await prisma.site.update({
      where: {
        id,
      },
      data: updateData,
    });

    // Parse the JSON fields for the response
    const parsedSite = {
      ...site,
      siteManager: site.siteManager ? JSON.parse(site.siteManager as string) : {},
      emergencyContacts: site.emergencyContacts ? JSON.parse(site.emergencyContacts as string) : [],
      safetyOfficer: site.safetyOfficer ? JSON.parse(site.safetyOfficer as string) : {},
      workHours: site.workHours ? JSON.parse(site.workHours as string) : {},
      safetyMeasures: site.safetyMeasures ? JSON.parse(site.safetyMeasures as string) : {},
      equipment: site.equipment ? JSON.parse(site.equipment as string) : [],
      permits: site.permits ? JSON.parse(site.permits as string) : [],
    };

    return NextResponse.json(parsedSite);
  } catch (error) {
    console.error('Error updating site:', error);
    return NextResponse.json(
      { error: 'Failed to update site' },
      { status: 500 }
    );
  }
}

// DELETE a site
export async function DELETE(request: Request, { params }: Params) {
  try {
    const { id } = params;
    
    // First check if the site exists
    const existingSite = await prisma.site.findUnique({
      where: {
        id,
      },
    });
    
    if (!existingSite) {
      return NextResponse.json(
        { error: 'Site not found' },
        { status: 404 }
      );
    }
    
    await prisma.site.delete({
      where: {
        id,
      },
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error('Error deleting site:', error);
    return NextResponse.json(
      { error: `Failed to delete site: ${error instanceof Error ? error.message : 'Unknown error'}` },
      { status: 500 }
    );
  }
} 