import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

// GET all sites
export async function GET() {
  try {
    const sites = await prisma.site.findMany({
      orderBy: {
        updatedAt: 'desc',
      },
    });
    
    return NextResponse.json(sites);
  } catch (error) {
    console.error('Error fetching sites:', error);
    return NextResponse.json(
      { error: 'Failed to fetch sites' },
      { status: 500 }
    );
  }
}

// POST create a new site
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Ensure JSON fields are properly stringified
    const site = await prisma.site.create({
      data: {
        name: body.name,
        location: body.location,
        projectType: body.projectType,
        startDate: body.startDate,
        expectedCompletionDate: body.expectedCompletionDate,
        totalWorkers: body.totalWorkers,
        safetyCompliance: body.safetyCompliance,
        lastUpdated: body.lastUpdated,
        siteManager: JSON.stringify(body.siteManager),
        emergencyContacts: JSON.stringify(body.emergencyContacts || []),
        safetyOfficer: JSON.stringify(body.safetyOfficer),
        siteStatus: body.siteStatus,
        workHours: JSON.stringify(body.workHours),
        safetyMeasures: JSON.stringify(body.safetyMeasures || {}),
        equipment: JSON.stringify(body.equipment || []),
        permits: JSON.stringify(body.permits || []),
      },
    });
    
    return NextResponse.json(site, { status: 201 });
  } catch (error) {
    console.error('Error creating site:', error);
    return NextResponse.json(
      { error: 'Failed to create site' },
      { status: 500 }
    );
  }
} 