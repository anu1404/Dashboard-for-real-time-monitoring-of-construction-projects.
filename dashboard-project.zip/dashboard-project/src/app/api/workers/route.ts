import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

// GET all workers
export async function GET() {
  try {
    const workers = await prisma.worker.findMany({
      orderBy: {
        updatedAt: 'desc',
      },
    });
    
    // Parse the JSON fields
    const parsedWorkers = workers.map(worker => ({
      ...worker,
      emergencyContact: worker.emergencyContact ? JSON.parse(worker.emergencyContact as string) : {},
      qualifications: worker.qualifications ? JSON.parse(worker.qualifications as string) : [],
      certifications: worker.certifications ? JSON.parse(worker.certifications as string) : [],
      workSchedule: worker.workSchedule ? JSON.parse(worker.workSchedule as string) : {},
      salary: worker.salary ? JSON.parse(worker.salary as string) : {},
      attendance: worker.attendance ? JSON.parse(worker.attendance as string) : {},
      performance: worker.performance ? JSON.parse(worker.performance as string) : {},
      documents: worker.documents ? JSON.parse(worker.documents as string) : [],
    }));
    
    return NextResponse.json(parsedWorkers);
  } catch (error) {
    console.error('Error fetching workers:', error);
    return NextResponse.json(
      { error: 'Failed to fetch workers' },
      { status: 500 }
    );
  }
}

// POST create a new worker
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Ensure JSON fields are properly stringified
    const worker = await prisma.worker.create({
      data: {
        firstName: body.firstName,
        lastName: body.lastName,
        employeeId: body.employeeId,
        department: body.department,
        position: body.position,
        dateOfBirth: body.dateOfBirth,
        dateOfJoining: body.dateOfJoining,
        contactNumber: body.contactNumber,
        email: body.email,
        address: body.address,
        emergencyContact: JSON.stringify(body.emergencyContact),
        qualifications: JSON.stringify(body.qualifications || []),
        certifications: JSON.stringify(body.certifications || []),
        workSchedule: JSON.stringify(body.workSchedule),
        salary: JSON.stringify(body.salary),
        attendance: JSON.stringify(body.attendance),
        performance: JSON.stringify(body.performance),
        documents: JSON.stringify(body.documents || []),
      },
    });
    
    // Parse the JSON fields for the response
    const parsedWorker = {
      ...worker,
      emergencyContact: worker.emergencyContact ? JSON.parse(worker.emergencyContact as string) : {},
      qualifications: worker.qualifications ? JSON.parse(worker.qualifications as string) : [],
      certifications: worker.certifications ? JSON.parse(worker.certifications as string) : [],
      workSchedule: worker.workSchedule ? JSON.parse(worker.workSchedule as string) : {},
      salary: worker.salary ? JSON.parse(worker.salary as string) : {},
      attendance: worker.attendance ? JSON.parse(worker.attendance as string) : {},
      performance: worker.performance ? JSON.parse(worker.performance as string) : {},
      documents: worker.documents ? JSON.parse(worker.documents as string) : [],
    };
    
    return NextResponse.json(parsedWorker, { status: 201 });
  } catch (error) {
    console.error('Error creating worker:', error);
    return NextResponse.json(
      { error: 'Failed to create worker' },
      { status: 500 }
    );
  }
} 