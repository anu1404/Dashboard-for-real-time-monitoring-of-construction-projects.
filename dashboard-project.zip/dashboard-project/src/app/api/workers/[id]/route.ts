import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

interface Params {
  params: {
    id: string;
  };
}

// GET a specific worker
export async function GET(request: Request, { params }: Params) {
  try {
    const { id } = params;
    const worker = await prisma.worker.findUnique({
      where: {
        id,
      },
    });

    if (!worker) {
      return NextResponse.json(
        { error: 'Worker not found' },
        { status: 404 }
      );
    }

    // Parse the JSON fields
    const parsedWorker = {
      ...worker,
      emergencyContact: worker.emergencyContact ? JSON.parse(worker.emergencyContact as string) : {},
      qualifications: worker.qualifications ? JSON.parse(worker.qualifications as string) : [],
      certifications: worker.certifications ? JSON.parse(worker.certifications as string) : [],
      workSchedule: worker.workSchedule ? JSON.parse(worker.workSchedule as string) : {},
      salary: worker.salary ? JSON.parse(worker.salary as string) : {},
      attendance: worker.attendance ? JSON.parse(worker.attendance as string) : {},
      performance: worker.performance ? JSON.parse(worker.performance as string) : {},
      documents: worker.documents ? JSON.parse(worker.documents as string) : [],
    };

    return NextResponse.json(parsedWorker);
  } catch (error) {
    console.error('Error fetching worker:', error);
    return NextResponse.json(
      { error: 'Failed to fetch worker' },
      { status: 500 }
    );
  }
}

// PATCH update a worker
export async function PATCH(request: Request, { params }: Params) {
  try {
    const { id } = params;
    const body = await request.json();

    // Prepare the data with stringified JSON fields
    const updateData: any = {};
    
    // Handle primitive fields
    if (body.firstName !== undefined) updateData.firstName = body.firstName;
    if (body.lastName !== undefined) updateData.lastName = body.lastName;
    if (body.employeeId !== undefined) updateData.employeeId = body.employeeId;
    if (body.department !== undefined) updateData.department = body.department;
    if (body.position !== undefined) updateData.position = body.position;
    if (body.dateOfBirth !== undefined) updateData.dateOfBirth = body.dateOfBirth;
    if (body.dateOfJoining !== undefined) updateData.dateOfJoining = body.dateOfJoining;
    if (body.contactNumber !== undefined) updateData.contactNumber = body.contactNumber;
    if (body.email !== undefined) updateData.email = body.email;
    if (body.address !== undefined) updateData.address = body.address;
    
    // Handle JSON fields
    if (body.emergencyContact !== undefined) updateData.emergencyContact = JSON.stringify(body.emergencyContact);
    if (body.qualifications !== undefined) updateData.qualifications = JSON.stringify(body.qualifications);
    if (body.certifications !== undefined) updateData.certifications = JSON.stringify(body.certifications);
    if (body.workSchedule !== undefined) updateData.workSchedule = JSON.stringify(body.workSchedule);
    if (body.salary !== undefined) updateData.salary = JSON.stringify(body.salary);
    if (body.attendance !== undefined) updateData.attendance = JSON.stringify(body.attendance);
    if (body.performance !== undefined) updateData.performance = JSON.stringify(body.performance);
    if (body.documents !== undefined) updateData.documents = JSON.stringify(body.documents);

    const worker = await prisma.worker.update({
      where: {
        id,
      },
      data: updateData,
    });

    // Parse the JSON fields for the response
    const parsedWorker = {
      ...worker,
      emergencyContact: worker.emergencyContact ? JSON.parse(worker.emergencyContact as string) : {},
      qualifications: worker.qualifications ? JSON.parse(worker.qualifications as string) : [],
      certifications: worker.certifications ? JSON.parse(worker.certifications as string) : [],
      workSchedule: worker.workSchedule ? JSON.parse(worker.workSchedule as string) : {},
      salary: worker.salary ? JSON.parse(worker.salary as string) : {},
      attendance: worker.attendance ? JSON.parse(worker.attendance as string) : {},
      performance: worker.performance ? JSON.parse(worker.performance as string) : {},
      documents: worker.documents ? JSON.parse(worker.documents as string) : [],
    };

    return NextResponse.json(parsedWorker);
  } catch (error) {
    console.error('Error updating worker:', error);
    return NextResponse.json(
      { error: 'Failed to update worker' },
      { status: 500 }
    );
  }
}

// DELETE a worker
export async function DELETE(request: Request, { params }: Params) {
  try {
    const { id } = params;
    
    // First check if the worker exists
    const existingWorker = await prisma.worker.findUnique({
      where: {
        id,
      },
    });
    
    if (!existingWorker) {
      return NextResponse.json(
        { error: 'Worker not found' },
        { status: 404 }
      );
    }
    
    await prisma.worker.delete({
      where: {
        id,
      },
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error('Error deleting worker:', error);
    return NextResponse.json(
      { error: `Failed to delete worker: ${error instanceof Error ? error.message : 'Unknown error'}` },
      { status: 500 }
    );
  }
} 