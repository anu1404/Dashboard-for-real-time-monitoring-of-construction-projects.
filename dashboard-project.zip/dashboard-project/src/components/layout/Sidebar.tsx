"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  LayoutDashboard,
  Users,
  Building2,
  AlertTriangle,
  Bell,
  Video,
} from "lucide-react";

const sidebarNavItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Live Feed",
    href: "/live-feed",
    icon: Video,
  },
  {
    title: "Workers",
    href: "/workers",
    icon: Users,
  },
  {
    title: "Sites",
    href: "/sites",
    icon: Building2,
  },
  {
    title: "Notifications",
    href: "/notifications",
    icon: Bell,
  },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <div className="flex h-screen w-72 flex-col border-r bg-background">
      <div className="p-6">
        <h2 className="text-2xl font-semibold">Construction Monitor</h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-3 p-4">
          {sidebarNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.href}
                variant={pathname === item.href ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 text-base py-6",
                  pathname === item.href && "bg-secondary",
                )}
                asChild
              >
                <Link href={item.href}>
                  <Icon className="h-5 w-5 mr-2" />
                  {item.title}
                </Link>
              </Button>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}
