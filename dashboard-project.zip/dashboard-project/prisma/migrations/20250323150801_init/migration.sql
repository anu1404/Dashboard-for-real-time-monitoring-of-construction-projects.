-- CreateTable
CREATE TABLE "Worker" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "employeeId" TEXT NOT NULL,
    "department" TEXT NOT NULL,
    "position" TEXT NOT NULL,
    "dateOfBirth" TEXT NOT NULL,
    "dateOfJoining" TEXT NOT NULL,
    "contactNumber" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "emergencyContact" JSONB NOT NULL,
    "qualifications" JSONB NOT NULL,
    "certifications" JSONB NOT NULL,
    "workSchedule" JSONB NOT NULL,
    "salary" JSONB NOT NULL,
    "attendance" JSONB NOT NULL,
    "performance" JSONB NOT NULL,
    "documents" JSONB NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "Site" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "location" TEXT NOT NULL,
    "projectType" TEXT NOT NULL,
    "startDate" TEXT NOT NULL,
    "expectedCompletionDate" TEXT NOT NULL,
    "totalWorkers" INTEGER NOT NULL,
    "safetyCompliance" REAL NOT NULL,
    "lastUpdated" TEXT NOT NULL,
    "siteManager" JSONB NOT NULL,
    "emergencyContacts" JSONB NOT NULL,
    "safetyOfficer" JSONB NOT NULL,
    "siteStatus" TEXT NOT NULL,
    "workHours" JSONB NOT NULL,
    "safetyMeasures" JSONB NOT NULL,
    "equipment" JSONB NOT NULL,
    "permits" JSONB NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "SafetyViolation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "type" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "timestamp" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "workerId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "SafetyViolation_workerId_fkey" FOREIGN KEY ("workerId") REFERENCES "Worker" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "Worker_employeeId_key" ON "Worker"("employeeId");
